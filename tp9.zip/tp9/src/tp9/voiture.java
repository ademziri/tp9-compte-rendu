package tp9;

public class voiture {
    private String marque;
    private String nommodele;
    private int anneeproduction;
    private int prixlocation;

    public voiture(String marque, String nomModele, int anneeProduction, int prixlocation) {
        this.marque = marque;
        this.nommodele = nomModele;
        this.anneeproduction = anneeProduction;
        this.prixlocation = prixlocation;
    }

    public String getMarque() {
        return marque;
    }

    public int getPrixLocation() {
        return prixlocation;
    }

   
    public String toString() {
        return "Marque: " + marque + ", Modele: " + nommodele + ", Prix de location: " + prixlocation;
    }
  
}

