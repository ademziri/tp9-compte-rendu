package tp9;

public class testagence {
    public static void main(String[] args) {
        agence agence = new agence(10);
       agence.ajout(new voiture("toyota","corolla",2020,80));
        agence.ajout(new voiture("clio","clio",2019,75));
        agence.ajout(new voiture("peugeot","208",2021,120));
        agence.ajout(new voiture("renault","megane",2018,95));

      
        System.out.println("voitures avec prix inferieur a 100:");
        agence.afficheSelection(new critereprix(100));
        System.out.println("\n voitures de marque clio:");
        agence.afficheSelection(new criteremarque("clio"));
    }
}

