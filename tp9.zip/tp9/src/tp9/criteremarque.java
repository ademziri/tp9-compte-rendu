package tp9;

public class criteremarque implements critere {
    private String marque;

    public criteremarque(String marque) {
        this.marque = marque;
    }

    public boolean estSatisfaitPar(voiture v) {
        return v.getMarque().equals(marque);
  }
}

