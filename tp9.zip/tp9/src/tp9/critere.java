package tp9;

public interface critere {
    boolean estSatisfaitPar(voiture v);
}

