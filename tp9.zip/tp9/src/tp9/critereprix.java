package tp9;

public class critereprix implements critere {
    private int prixmax;

    public critereprix(int prixmax) {
        this.prixmax = prixmax;
    }

   
    public boolean estSatisfaitPar(voiture v) {
        return v.getPrixLocation()<prixmax;
    }
}

