package tp9;

public class agence {
    private voiture[] voitures;
    private int nbrV;

    public agence(int capacite) {
        voitures = new voiture[capacite];
        nbrV=0;
    }

    public void ajout(voiture v) {
        if (nbrV<voitures.length) {
            voitures[nbrV++]=v;}
  }

    public void afficheSelection(critere c) {
        for (int i =0; i<nbrV; i++) {
            if (c.estSatisfaitPar(voitures[i])) {
                System.out.println(voitures[i]);
     }
    }
  }
}

